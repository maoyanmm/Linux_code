#include"cloud_client.hpp"

#define FILE_NAME_DIR "./fileNameList"
#define LISTEN_DIR "./backup/"
#define SERVER_IP "192.168.132.128"
#define SERVER_PORT 4418

int main()
{
	CloudClient client(LISTEN_DIR, FILE_NAME_DIR, SERVER_IP, SERVER_PORT);
	client.Start();
	return 0;
}